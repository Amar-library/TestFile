import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { PenaltyComponent } from './penalty/penalty.component';
import { BookLocalDBService } from '../service/book-local-db.service';

@NgModule({
  declarations: [
    AppComponent,    
    PenaltyComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: PenaltyComponent, pathMatch: 'full' },      
    ])
  ],
  providers: [BookLocalDBService],
  bootstrap: [AppComponent]
})
export class AppModule { }
