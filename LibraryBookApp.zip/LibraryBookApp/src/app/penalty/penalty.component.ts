import { Component, OnInit } from '@angular/core';
import { BookLocalDBService } from '../../service/book-local-db.service';

@Component({
  selector: 'app-penalty',
  templateUrl: './penalty.component.html',
  styleUrls: ['./penalty.component.css']
})
export class PenaltyComponent implements OnInit {

  constructor( private bookLocalDBService: BookLocalDBService) {}

  ngOnInit() {
  }
  public count = 0;
  public bookname: string = '';
  public checkedDate = new Date();
  public returnedDate = new Date();
  public countries = this.bookLocalDBService.country;
  public holidays = this.bookLocalDBService.IndianHolidays;
  public selectedVal: string = '';
  public msg: string = '';

  public book = {bookname: this.bookname, checkedDate: this.checkedDate }

  public Calculate()
  {
      let startDate = new Date(this.checkedDate);
      let endDate = new Date(this.returnedDate);
      
      // Calculate days between dates
      var millisecondsPerDay = 86400 * 1000; // Day in milliseconds
      startDate.setHours(0, 0, 0, 1);  // Start just after midnight
      endDate.setHours(23, 59, 59, 999);  // End just before midnight
      var diff = endDate.getTime() - startDate.getTime();  // Milliseconds between datetime objects    
      var days = Math.ceil(diff / millisecondsPerDay);

      if (days <= 0)
          return days;        
      
      // Subtract two weekend days for every week in between
      var weeks = Math.floor(days / 7);
      days = days - (weeks * 2);

      // Handle special cases
      var startDay = startDate.getDay();
      var endDay = endDate.getDay();
      
      // Remove weekend not previously removed.   
      if (startDay - endDay > 1)
          days = days - 2;

      let val = this.selectedVal.split('~');
      // Remove start day if span starts on firstDay but ends before LastDay
      if (startDay.toString() == val[0] && endDay.toString() != val[1])
          days = days - 1;

      // Remove end day if span ends on LastDay but starts after FirstDay
      if (endDay.toString() == val[1] && startDay.toString() != val[0])
          days = days - 1;
      
      if(days > 10)
      {
        let penaltyFee = (days-10)*5;
        this.msg = 'You should pay the penaltyFee: ' + penaltyFee;
      }
  }

  CheckHoliday(date) {
    var thisMonth = date.getMonth();
    var thisDate = date.getDate();
    var thisDay = date.getDay();

    // Loop through the holidays
    for (let hdays of this.holidays){
      if (parseInt(thisMonth) == parseInt(hdays[0].toString()) - 1 && thisDate == hdays[1].toString()) {
        if(thisDay == 0 || thisDay == 6) {
           // Weekend holiday
        }
        else { 
           // Weekday holiday
        }
        return false; // Exit the loop
      }
      else if (thisDay == 0 || thisDay == 6) { 
        // Weekend day
      }
    }    
  }

  // addBookDetail()
  // {
  //   this.count++;
  //   this.book.bookname = this.bookname;
  //   this.book.checkedDate = this.checkedDate;
  //   this.bookLocalDBService.setItem(this.count.toString(), JSON.stringify(this.book))
  // }
}
