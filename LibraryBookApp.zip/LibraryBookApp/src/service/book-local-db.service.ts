import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookLocalDBService {
  constructor() { }

  public country = [
    {
      id:"1",
      name: "India",
      weekEndDays:"0~6", // Saturday, Sunday
      nHolidays:""
    },
    {
      id:"2",
      name: "Dubai",
      weekEndDays:"5~6" // Friday, Saturday

    },
    {
      id:"3",
      name: "Turkey",
      weekEndDays:"0~1" // Sunday, Monday
    }
   ]

   IndianHolidays = [
		[1, 1, 'News Year day'], [2, 15, 'Indian Day'], [4, 3, 'Good Friday'],
		[5, 1, 'May Day'], [7, 1, 'Ramzan Day'], [9, 7, 'Pooja Day'],
		[10, 12, 'Diwali'], [12, 25, 'Christmas']
		];

  public setItem(key: string, value: string) {
    localStorage.setItem(key, value);
  }    
  public getItem(key: string){ 
    return localStorage.getItem(key)
  }
  public removeItem(key:string) {
    localStorage.removeItem(key);
  }
  public clear(){
    localStorage.clear(); 
  }
}
