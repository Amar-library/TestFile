import { TestBed } from '@angular/core/testing';

import { BookLocalDBService } from './book-local-db.service';

describe('BookLocalDBService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BookLocalDBService = TestBed.get(BookLocalDBService);
    expect(service).toBeTruthy();
  });
});
