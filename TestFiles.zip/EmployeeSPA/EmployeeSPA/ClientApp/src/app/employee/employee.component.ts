import { Component, OnInit } from '@angular/core';
import { Employee} from '../employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  public employees: Employee[];
  employee: Employee = new Employee();
  submitted: false;
  constructor( private employeeService: EmployeeService) { }

  ngOnInit() {
    this.getEmployeeList();
  }

  onSubmit(){
    this.employeeService.SaveEmployee(this.employee).subscribe(
      data => { this.getEmployeeList()}, error => console.log(error));
  }

  getEmployeeList(){
    this.employeeService.getAllEmployees()
      .subscribe(data => {        
        this.employees = data;
      }, error => console.log(error));
  }
}
