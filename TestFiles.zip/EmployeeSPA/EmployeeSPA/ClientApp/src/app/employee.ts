import { DecimalPipe } from "@angular/common";

export class Employee {
    id: number;
    name: string;
    age: number;
    dateofBirth: Date;
    salary: number;
}