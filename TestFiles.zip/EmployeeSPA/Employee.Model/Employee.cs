﻿using System;

namespace EmployeeModel
{
    public class Employee
    {
        public int id { get; set; }
        public string Name { get; set; }
        public DateTime DateofBirth { get; set; }
        public int Age { get; set; }
        public int Salary { get; set; }
    }
}
