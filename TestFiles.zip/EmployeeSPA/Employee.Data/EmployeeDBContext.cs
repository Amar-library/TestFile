﻿using System;
using Microsoft.EntityFrameworkCore;
using EmployeeModel;

namespace EmployeeData
{
    public class EmployeeDBContext : DbContext
    {
        public EmployeeDBContext(DbContextOptions<EmployeeDBContext> options) : base(options)
        {
        }

        public DbSet<Employee> Employee { get; set; }
    }
}
